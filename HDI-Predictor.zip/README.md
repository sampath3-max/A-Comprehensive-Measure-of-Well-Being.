# HDI Predictor
1. pip install flask pandas scikit-learn numpy
2. Replace HDI.csv with a real dataset (sample included).
3. python train_model.py
4. python app.py
