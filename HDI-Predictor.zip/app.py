from flask import Flask,render_template,request
import pickle
import numpy as np
app=Flask(__name__)
model=pickle.load(open('HDI.pkl','rb'))
@app.route('/')
def home(): return render_template('index.html')
@app.route('/predict',methods=['POST'])
def predict():
    vals=[float(request.form[k]) for k in ['life','mean','expected','gni']]
    hdi=float(model.predict([vals])[0])
    if hdi>=0.8:c='Very High'
    elif hdi>=0.7:c='High'
    elif hdi>=0.55:c='Medium'
    else:c='Low'
    return render_template('result.html',score=round(hdi,3),cat=c)
app.run(debug=True)
