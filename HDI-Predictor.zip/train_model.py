import pandas as pd,pickle
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
df=pd.read_csv('HDI.csv')
X=df[['Life Expectancy','Mean Years of Schooling','Expected Years of Schooling','GNI Per Capita']]
y=df['HDI Score']
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42)
m=LinearRegression().fit(Xtr,ytr)
pickle.dump(m,open('HDI.pkl','wb'))
print('R2',m.score(Xte,yte))
